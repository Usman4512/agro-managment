# 🚀 Render + Aiven Deployment Guide — Agro System
# 100% FREE — No Credit Card Required

===================================================
PART 1 — AIVEN (Free MySQL Database)
===================================================

STEP 1 — Create Aiven Account
------------------------------
1. Go to: https://aiven.io
2. Click "Sign Up Free"
3. Sign up with Google or email — NO card needed
4. Verify your email

STEP 2 — Create Free MySQL Database
-------------------------------------
1. After login, click "Create Service"
2. Choose "MySQL"
3. Select plan: "Free" (Hobbyist - $0)
4. Choose any cloud region (pick closest — e.g. Google Cloud)
5. Service name: type "agro-mysql"
6. Click "Create Free Service"
7. Wait 2-3 minutes for it to start (status becomes "Running")

STEP 3 — Get Your Database Credentials
----------------------------------------
1. Click on your "agro-mysql" service
2. Go to "Overview" tab
3. You will see a "Connection information" section
4. Copy these values — you need them later:

   Host:     something.aivencloud.com
   Port:     (a number like 12345 — NOT 3306, Aiven uses custom ports)
   Database: defaultdb
   Username: avnadmin
   Password: (shown — copy it)

   ⚠️ IMPORTANT: Copy the PORT number carefully — it is NOT 3306!

===================================================
PART 2 — RENDER (Free Flask Hosting)
===================================================

STEP 4 — Create Render Account
--------------------------------
1. Go to: https://render.com
2. Click "Get Started for Free"
3. Sign up with GitHub — NO card needed
4. This connects Render to your GitHub automatically

STEP 5 — Create New Web Service
---------------------------------
1. In Render dashboard, click "New +"
2. Choose "Web Service"
3. Connect your GitHub repo: select "MY-Agro-Farm"
4. Click "Connect"

STEP 6 — Configure the Service
--------------------------------
Fill in these settings:

   Name:           agro-system
   Region:         Choose any (Singapore is close to Pakistan)
   Branch:         main
   Runtime:        Python 3
   Build Command:  pip install -r requirements.txt
   Start Command:  gunicorn --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 60 app:app
   Plan:           Free

Click "Advanced" to add environment variables (next step).

STEP 7 — Add Environment Variables
------------------------------------
Click "Add Environment Variable" for each one below.
Fill in YOUR values from Aiven (Step 3):

   Key                  Value
   ---                  -----
   SECRET_KEY           your-random-secret-key-here
   MYSQL_HOST           (paste Host from Aiven)
   MYSQL_USER           avnadmin
   MYSQL_PASSWORD       (paste Password from Aiven)
   MYSQL_DB             defaultdb
   MYSQL_PORT           (paste Port from Aiven — e.g. 12345)
   MYSQL_SSL            True
   MAIL_SERVER          smtp.gmail.com
   MAIL_PORT            587
   MAIL_USE_TLS         True
   MAIL_USERNAME        your-email@gmail.com
   MAIL_PASSWORD        your-16-char-app-password
   MAIL_DEFAULT_SENDER  Agro System <your-email@gmail.com>
   ADMIN_EMAIL          your-email@gmail.com
   JAZZCASH_NUMBER      03001234567
   EASYPAISA_NUMBER     03001234567
   OWNER_NAME           Your Full Name

STEP 8 — Deploy!
-----------------
1. Click "Create Web Service"
2. Render will build and deploy your app (takes 3-5 minutes)
3. You can watch the build logs live
4. When you see "Your service is live" — done!

STEP 9 — Get Your Live URL
---------------------------
Your app URL will be:
   https://agro-system.onrender.com
   (or similar — shown at top of Render dashboard)

Open it — your app is live! 🎉

===================================================
FIRST LOGIN
===================================================

Email:    your-email@gmail.com
Password: admin123

⚠️ Change the password immediately after first login!

===================================================
TROUBLESHOOTING
===================================================

Build fails — "mysqlclient" error
→ This is fixed in the updated code. If still fails, check build logs.

"SSL connection error"
→ Make sure MYSQL_SSL=True is set in environment variables

"Can't connect to database"
→ Double check MYSQL_HOST, MYSQL_PORT from Aiven
→ Port is NOT 3306 — copy the exact number from Aiven

App loads but shows 500 error
→ Go to Render dashboard → your service → "Logs" tab
→ Look for the error message

Free plan — app sleeps after 15 minutes
→ On free Render plan, app sleeps if no traffic
→ First visit after sleep takes ~30 seconds to wake up
→ This is normal for free plan

After code changes — redeploy
→ Just push to GitHub: git add . && git commit -m "update" && git push
→ Render auto-deploys on every push

===================================================
CHECKLIST
===================================================
[ ] Aiven account created
[ ] MySQL service created on Aiven (Free plan)
[ ] Copied Host, Port, Password from Aiven
[ ] Render account created with GitHub
[ ] Web service created pointing to MY-Agro-Farm repo
[ ] All environment variables added in Render
[ ] App deployed successfully
[ ] Opened live URL
[ ] Logged in and changed admin password
