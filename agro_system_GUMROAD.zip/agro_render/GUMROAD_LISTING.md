=======================================================
  GUMROAD LISTING — Copy & Paste This
=======================================================

PRODUCT NAME:
-------------
🌾 Agro Farm Management System — Full Python Flask Source Code


PRICE SUGGESTION:
-----------------
$19  — good starting price, easy to sell
$29  — if you want more profit (still reasonable)
$9   — if you want many quick sales


SHORT DESCRIPTION (shown under title):
---------------------------------------
Complete farm management web app built with Python Flask + MySQL.
Admin panel, crop tracking, market rates, JazzCash/Easypaisa payments,
email verification, subscription system. Deploy free in 15 minutes.


FULL DESCRIPTION (paste into Gumroad description box):
--------------------------------------------------------

🌾 AGRO FARM MANAGEMENT SYSTEM — Complete Python Flask Web App

A fully functional farm management SaaS platform built for Pakistani farmers.
Comes with complete source code, deployment guide, and everything you need
to launch your own farm management website.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ WHAT YOU GET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👨‍🌾 FARMER FEATURES:
• User registration with email verification
• Login/logout, forgot password, reset password
• Personal profile management
• Crop management — add, edit, track planting to harvest
• Inventory tracking — seeds, fertilizers, tools, equipment
• Expense tracking with categories
• Live market rates — crop prices for major Pakistani cities
• Notifications system
• 30-day free trial system built in

🛡️ ADMIN PANEL:
• Full admin dashboard with statistics
• Manage all registered farmers
• View farmer details and activity logs
• Manage crop market rates (add/edit/delete)
• Approve or reject payment requests
• Generate reports
• Suspend or activate farmer accounts

💳 PAYMENT SYSTEM:
• JazzCash support
• Easypaisa support
• Payment screenshot upload
• Admin approval workflow
• Automatic subscription activation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ TECH STACK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Backend: Python 3.10 + Flask 3.0
• Database: MySQL
• Frontend: Bootstrap + Jinja2 templates
• Email: Gmail SMTP
• Deploy: Render.com + Aiven (both FREE)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 WHAT'S INCLUDED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Complete source code (Python + HTML + CSS)
✅ 30+ HTML templates
✅ Auto database setup (tables created on first run)
✅ Sample data — 14 crops with Pakistani market prices
✅ Step-by-step deployment guide (free hosting)
✅ Environment variables setup guide
✅ Troubleshooting guide

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ DEPLOY IN 15 MINUTES — 100% FREE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This project deploys completely free:
• Render.com hosts your Flask app — free tier, no credit card
• Aiven.io provides free MySQL database — no credit card

Full deployment guide included inside the zip.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🇵🇰 BUILT FOR PAKISTAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Rabi, Kharif, Zaid crop seasons
• Major Pakistani cities in market rates
• JazzCash & Easypaisa payment integration
• PKR currency
• All provinces included

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💬 SUPPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Questions? Message me through Gumroad — I reply within 24 hours.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📄 LICENSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Use for your own personal project
✅ Use to build your own SaaS business
✅ Modify however you want
❌ Do not resell the source code as-is


TAGS (add these in Gumroad):
------------------------------
python, flask, agriculture, farm management, mysql, source code,
pakistan, web app, saas, bootstrap, admin panel


THUMBNAIL / COVER IMAGE TIPS:
------------------------------
Take screenshots of these pages for your Gumroad listing images:
1. Dashboard page (main stats page)
2. Crop list page
3. Admin dashboard
4. Market rates page
5. Login page

Use https://screenshot.guru or just press Win+Shift+S on Windows
to take screenshots of your deployed app.

=======================================================
