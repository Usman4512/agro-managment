# 🌾 Agro Farm Management System

A complete web-based farm management system built with **Python Flask** and **MySQL**.
Designed for Pakistani farmers to manage crops, track expenses, monitor market rates, and run a subscription-based SaaS business.

---

## 🚀 Live Demo

Deploy your own in minutes — full deployment guide included!

---

## ✨ Features

### 👨‍🌾 Farmer Panel
- ✅ User registration with email verification
- ✅ Login / logout with session management
- ✅ Forgot password & reset via email
- ✅ Personal profile management
- ✅ Crop management (add, edit, delete, track status)
- ✅ Inventory tracking (seeds, fertilizer, tools, equipment)
- ✅ Expense tracking with categories
- ✅ Market rates — view live crop prices by city
- ✅ Notifications system
- ✅ 30-day free trial built in
- ✅ Subscription plans (Basic / Premium)

### 🛡️ Admin Panel
- ✅ Admin dashboard with full statistics
- ✅ Manage all registered farmers
- ✅ View farmer details and activity logs
- ✅ Manage crop market rates
- ✅ Approve / reject payment requests
- ✅ Generate reports
- ✅ Suspend / activate accounts

### 💳 Payment System
- ✅ JazzCash payment support
- ✅ Easypaisa payment support
- ✅ Screenshot upload for payment proof
- ✅ Admin approval workflow
- ✅ Subscription activation on approval

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.10 / Flask 3.0 |
| Database | MySQL |
| Frontend | HTML5, CSS3, Bootstrap, Jinja2 |
| Email | Gmail SMTP |
| Auth | Session-based with email verification |
| Hosting | Render.com (free) |
| Database Host | Aiven MySQL (free) |

---

## 📁 Project Structure

```
agro_system/
├── app.py               # Main Flask app entry point
├── config.py            # All configuration (reads from env vars)
├── requirements.txt     # Python dependencies
├── render.yaml          # Render deployment config
├── models/
│   └── db.py            # Database connection + all DB functions
├── routes/
│   ├── auth.py          # Register, login, verify, reset password
│   ├── dashboard.py     # Farmer dashboard
│   ├── crops.py         # Crop management + inventory + expenses
│   ├── rates.py         # Market rates
│   ├── admin.py         # Admin panel
│   └── payment.py       # Payment requests
├── utils/
│   └── email.py         # Email sending functions
├── templates/           # All HTML pages (30+ templates)
└── static/              # CSS, JS, images
```

---

## ⚡ Quick Deploy (Free)

This project deploys 100% free using:
- **Render.com** — hosts your Flask app (free tier)
- **Aiven.io** — free MySQL database (no credit card)

Full step-by-step guide included in `RENDER_AIVEN_GUIDE.md`

---

## 🔧 Environment Variables

All configuration is done through environment variables — no hardcoded credentials.

```env
SECRET_KEY=your-secret-key
MYSQL_HOST=your-aiven-host
MYSQL_USER=avnadmin
MYSQL_PASSWORD=your-password
MYSQL_DB=defaultdb
MYSQL_PORT=your-port
MYSQL_SSL=True
MAIL_USERNAME=your-gmail@gmail.com
MAIL_PASSWORD=your-app-password
ADMIN_EMAIL=your-email@gmail.com
JAZZCASH_NUMBER=your-jazzcash-number
EASYPAISA_NUMBER=your-easypaisa-number
OWNER_NAME=Your Name
```

---

## 🏃 Local Development

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/agro-system.git
cd agro-system

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables (copy .env.example to .env and fill in)
cp .env.example .env

# 4. Run the app
python app.py
```

Open http://localhost:5000

---

## 🔑 Default Admin Login

After first deploy:
- **Email:** whatever you set as `ADMIN_EMAIL`
- **Password:** `admin123`

⚠️ Change the password immediately after first login!

---

## 📦 What's Included

- ✅ Complete source code
- ✅ 30+ HTML templates
- ✅ Database schema (auto-created on first run)
- ✅ Sample crop market rate data (14 crops, major Pakistani cities)
- ✅ Full deployment guide (Render + Aiven)
- ✅ Environment variable setup guide
- ✅ Troubleshooting guide

---

## 🇵🇰 Built for Pakistan

- Crop seasons: Rabi, Kharif, Zaid
- Major Pakistani cities included in market rates
- JazzCash and Easypaisa payment support
- PKR currency throughout
- Provinces: Punjab, Sindh, KPK, Balochistan, etc.

---

## 📄 License

This project is sold for personal and commercial use.
You may use it for your own SaaS product.
You may NOT resell the source code as-is.

---

## 💬 Support

If you have any questions about setup or deployment, contact the seller through Gumroad.
